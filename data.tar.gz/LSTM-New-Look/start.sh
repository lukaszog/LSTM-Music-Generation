python3 train_airline.py
